% close all;clc;clear;

%% This is a demo of using the saliency detection method
% The program reads images from the 'images' folder, and save the saliency
% maps into the 'saliencyMaps' folder.

D = dir('Images\');
imageNum = size(D,1);
idx = 1;

for n = 1:imageNum
    if strcmp(D(n).name(end),'g') || strcmp(D(n).name(end),'p')
        %read
        image = imread(['Images\',D(n).name]);
        
        %Get the saliency map
        saliencyMap = GetSaliencyMap(image);
        
        %save
        imwrite(saliencyMap, ['saliencyMaps\',D(n).name(1:end-4),'_saliency.bmp']);
        fprintf('Image %d processed.\n', idx);
        idx = idx+1;
    end
end
