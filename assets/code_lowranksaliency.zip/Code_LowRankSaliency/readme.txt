This is a matlab implementation of the saliency detection method: 
A Unified Approach to Salient Object Detection via Low Rank Matrix Recovery.

Before you use the code, some external matlab code need to be compiled first. Please run edison_matlab_interface/compile_edison_wrapper.m for the comilation of mean shift segmentation.

If necessary, please also run matlabPyrTools/MEX/compilePyrTools.m for the steerable pyramid in feature extraction, and put the .mex file in your matlab directory to avoid warnings.

The main function of the method is developed in GetSaliencyMap.m, in which the input is an image, and the output is a corresponding saliency map. 

An example of using the method is also provided in Demo.m, which reads the images from the folder "/images", and saves corresponding saliency maps in "/saliencyMaps".

Please cite the following paper when you report the results using the code:
Xiaohui Shen and Ying Wu, A Unified Approach to Salient Object Detection via Low Rank Matrix Recovery, CVPR 2012.

Any questions please contact Xiaohui Shen at xsh835@eecs.northwestern.edu.


-------------------------

The method also used other code provided by other researchers, including the EDISON system for mean shift segmentation[1],
the steerable pyramid[2], Gabor filters[3], and the Augmented Lagrange Multiplier (ALM) method for low rank matrix recovery[4]. We thank them for sharing the code, and the copyrights belong to their respective developers.

[1]http://coewww.rutgers.edu/riul/research/code/EDISON/index.html
[2]http://www.cns.nyu.edu/~eero/steerpyr/
[3]http://www.csse.uwa.edu.au/~pk/research/matlabfns/
[4]http://perception.csl.illinois.edu/matrix-rank/sample_code.html

-------------------------