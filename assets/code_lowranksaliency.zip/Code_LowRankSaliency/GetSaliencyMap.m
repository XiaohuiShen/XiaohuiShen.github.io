function saliencyMap = GetSaliencyMap(image, faceLocation)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a matlab implementation of the salient object detection method:
% A Unified Approach to Salient Object Detection via Low Rank Matrix Recovery
% by Xiaohui Shen, updated on Jan. 24th, 2013.

% Input:
% image -- input image;
% faceLocation(OPTIONAL) -- if face detection is enabled, locations of the 
% detected faces. It is a n*4 matrix, n is the detected face number, and each row
% is the bounding box of a face, stored as [left, top, right bottom]. If 
% face detection is disabled, or there is no face in the image, no input is
% needed.

% Output:
% saliencyMap -- a gray-scale image indicating the saliency, with the same
% size as the input image.

% For any questions, please contact Xiaohui Shen at
% xsh835@eecs.northwestern.edu

% Copyright: Northwestern Vision Group, Northwestern University, Evanston,
% IL.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

path(path, './RPCA/exact_alm_rpca/exact_alm_rpca');
path(path, './edison_matlab_interface');
   
[height,width,channel] = size(image);
if channel == 1
    colorimage = zeros(height, width, 3);
    colorimage(:,:,1) = image;
    colorimage(:,:,2) = image;
    colorimage(:,:,3) = image;
    image = colorimage;
end

% Check if the face prior exists
if nargin == 1
    validFacePrior = 0;
else
    validFacePrior = 1;
end

%% Load trained data, including learned feature transformation, and color prior
fileID = fopen('TrainedData','rb');
T = fread(fileID, 53*53, 'double');
T = reshape(T, 53,53);
ColorPrior = fread(fileID, 20*20, 'double');
ColorPrior = reshape(ColorPrior, 20,20);
fclose(fileID);

%% Mean-shift segmentation and feature extraction
[fimage, labels, modes, regSize] = edison_wrapper(image, @ExtractFeature, 'SpatialBandWidth', 7, 'RangeBandWidth', 12, 'MinimumRegionArea', 200);
         
features = double(modes)'./255;
colorFeatures = features(:,1:3);
medianR = median(colorFeatures(:,1));
medianG = median(colorFeatures(:,2));
medianB = median(colorFeatures(:,3));
features(:,1:3) = (features(:,1:3)-1.2*repmat([medianR, medianG, medianB],size(features,1),1))*1.5;

%% Generate high-level prior map
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

featNum = size(modes,2);
Priors = zeros(1,featNum);

%Center prior
centerPriorMap = zeros(height,width);
center = [height/2,width/2];
sigma = min(height,width)/2.5;
for x = 1:height
    for y = 1:width
        d = norm([x,y]-center);
        centerPriorMap(x,y) = exp(-d^2/(2*sigma^2));
    end
end

%Face prior
if validFacePrior == 1
    numOfFace = size(faceLocation,1);
    for i = 1:numOfFace
        left = floor(faceLocation(i,1));
        top = floor(faceLocation(i,2));
        right = floor(faceLocation(i,3));
        bottom = floor(faceLocation(i,4));
        centerPriorMap(top:bottom, left:right) = centerPriorMap(top:bottom, left:right)+0.2;
    end
end

%Color prior

%Get the mean location for each region
meanLocation = zeros(featNum,3);
locCollection = cell(featNum,1);
for i=1:featNum
    locCollection{i} = [];
end
for x = 1:height
    for y = 1:width
        label = labels(x,y);
        locCollection{label+1} = [locCollection{label+1}; x,y];
        meanLocation(label+1,1) = meanLocation(label+1,1)+x;
        meanLocation(label+1,2) = meanLocation(label+1,2)+y;
        meanLocation(label+1,3) = meanLocation(label+1,3)+1;
    end
end
meanLocation(:,1) = floor(meanLocation(:,1)./meanLocation(:,3));
meanLocation(:,2) = floor(meanLocation(:,2)./meanLocation(:,3));

for index = 1:featNum
    mx = meanLocation(index,1);
    my = meanLocation(index,2);
    variance = sum(std(locCollection{index},0,1));
    prior = centerPriorMap(mx,my)*exp(-variance/50);
    
    nR = colorFeatures(index,1)/(sum(colorFeatures(index,:))+1e-6);
    nG = colorFeatures(index,2)/(sum(colorFeatures(index,:))+1e-6);
    x = min(floor(nR/0.05)+1,20);
    y = min(floor(nG/0.05)+1,20);
    prior = prior*(ColorPrior(x,y)+0.5)/1.5;
    Priors(index) = prior;
end

%Spatial smoothing on the high-level priors
regionDist = zeros(featNum, featNum);
featDist = zeros(featNum, featNum);
for i = 1:featNum
    for j = i:featNum
        regionDist(i,j) = sqrt(double((meanLocation(i,1)-meanLocation(j,1))^2+(meanLocation(i,2)-meanLocation(j,2))^2));
        regionDist(j,i) = regionDist(i,j);
        featDist(i,j) = norm(features(i,:)-features(j,:));
        featDist(j,i) = featDist(i,j);
    end
end

SmoothedPriors = zeros(size(Priors));
for i = 1:featNum
    totalweight = 0;
    for j = 1:featNum
        weight = exp(-regionDist(i,j)/20);
        totalweight = totalweight+weight;
        SmoothedPriors(i) = SmoothedPriors(i)+Priors(j)*weight;
    end
    SmoothedPriors(i) = SmoothedPriors(i)/totalweight;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Feature transformation and high-level prior integration
features = features*T;
for i = 1:featNum
    features(i,:) = SmoothedPriors(i).*features(i,:);
end

%% Low rank matrix recovery
[A E] = exact_alm_rpca(features,0.06);
rawSaliency = sum(abs(E),2);

%% Smoothing
SmoothedSaliency = zeros(size(rawSaliency));
for i = 1:featNum
    if regSize(i)>0.05*width*height
        SmoothedSaliency(i) = rawSaliency(i);
        continue;
    end
    totalweight = 0;
    for j = 1:featNum        
        if (regionDist(i,j)<min(width,height)/3)
            weight = exp(-featDist(i,j)*2);
            totalweight = totalweight+weight;
            SmoothedSaliency(i) = SmoothedSaliency(i)+rawSaliency(j)*weight;
        end
    end
    SmoothedSaliency(i) = SmoothedSaliency(i)/totalweight;
    variance = sum(std(locCollection{i},0,1));
    SmoothedSaliency(i) = SmoothedSaliency(i)*exp(-variance/50);
end

%% Generate the final saliency map
saliencyMap = zeros(height, width);
for i=1:height
    for j=1:width
        label = labels(i,j);
        saliencyMap(i,j) = SmoothedSaliency(label+1);
    end
end
saliencyMap = (saliencyMap-min(saliencyMap(:)))*255/(max(saliencyMap(:))-min(saliencyMap(:)));
saliencyMap = saliencyMap*255/max(saliencyMap(:));
saliencyMap = uint8(floor(saliencyMap));
% saliencyMap = saliencyMap*255/max(saliencyMap(:));
